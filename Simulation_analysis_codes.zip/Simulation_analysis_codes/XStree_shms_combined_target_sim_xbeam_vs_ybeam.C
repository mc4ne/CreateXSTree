//This code is to plot z_ini and z_recon with weighted rate and Q2<11 GeV^2 cut from mc_single_arm simulation for GE180 glass windows
//note that PBosted::GetXS() will not work for Q2>11, I give up these points
//For HMS: ztg0; ztg; Q2; p_rate_ge180; p_rate_he3 (T)
//For SHMS:ztg0; ztg; Q2; p_rate_ge180; p_rate_he3(T)
//Plot 2D histogram of xfp vs yfp

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include "TH2F.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TStyle.h"
#include "TVirtualPad.h"
#include <string>
#include <sstream>
#include <cmath>

using namespace std;
void XStree_shms_combined_target_sim_xbeam_vs_ybeam()
{
  //Load root file
  /*
  //kin-3
  TString rootfile_path_down="test3_win_down_xstree.root";
  TString rootfile_path_up="test3_win_up_xstree.root";
  TString rootfile_path_he3="test3_xstree.root";
  TString rootfile_path_replay="hms_replay_production_all_03147_200500.root";
  //TString rootfile_path_replay="hms_replay_production_all_03072_200500.root";//empty target
  */
  /*
  //kin-4
  TString rootfile_path_down="test4_win_down_xstree.root";
  TString rootfile_path_up="test4_win_up_xstree.root";
  TString rootfile_path_he3="test4_xstree.root";
  TString rootfile_path_replay="hms_replay_production_all_03408_200500.root";
  //TString rootfile_path_replay="hms_replay_production_all_03077_200500.root";//empty target
  */
  //[SHMS]
  
  //kin-B
  TString rootfile_path_down="shms_b_win_downstream_xstree.root";
  TString rootfile_path_up="shms_b_win_upstream_xstree.root";
  TString rootfile_path_he3="shms_b_xstree.root";
  TString rootfile_path_n2="shms_b_n2_xstree.root";
  TString rootfile_path_replay="shms_replay_production_all_10602_200500.root";
  //TString rootfile_path_replay="shms_replay_production_all_10267_200500.root";//empty target
  
  
  /*
  //kin-C
  TString rootfile_path_down="shms_c_win_downstream_xstree.root";
  TString rootfile_path_up="shms_c_win_upstream_xstree.root";
  TString rootfile_path_he3="shms_c_xstree.root";
  TString rootfile_path_n2="shms_c_n2_xstree.root";
  TString rootfile_path_replay="shms_replay_production_all_10435_200500.root";
  //TString rootfile_path_replay="shms_replay_production_all_10262_200500.root";//empty target
  */ 
   
 //TTree strings
 TString p_xfp_sim="vx";
 TString p_yfp_sim="vy";
 TString hist2D="(200, -1, 1, 200, -1, 1)";//x and y bin range
 TString hist1D="(200,-1,1)";//1d histogram range
 /*
 //[HMS]
 TString p_xfp_re="H.react.x";
 TString p_yfp_re="H.react.y";
 */
 
  
 //[SHMS]
 TString p_xfp_re="P.react.x";
 TString p_yfp_re="P.react.y";
 TString p_ibcm1_cut="ibcm1>1.0";//current>1.0 uA
 
  
  
 
 
 
 
 //[downstream window]
 TFile *f_down=new TFile(rootfile_path_down);
  TTree *tr_down=(TTree*)f_down->Get("T");//specify TTree
  TCanvas *c_down=new TCanvas("c_down","",1800,1200);
  c_down->Divide(3,2);
  c_down->cd(1);
  tr_down->Draw(p_yfp_sim+":"+p_xfp_sim+">>h_down_win"+hist2D,"","colz");;
  TH2F *h_down_win = (TH2F*)gDirectory->Get("h_down_win");//get histogram from TTree to h1
  
  
  
//[upstream window]
  TFile *f_up=new TFile(rootfile_path_up);
  TTree *tr_up=(TTree*)f_up->Get("T");//specify TTree
  c_down->cd(2);
  tr_up->Draw(p_yfp_sim+":"+p_xfp_sim+">>h_up_win"+hist2D,"","colz");;
  TH2F *h_up_win = (TH2F*)gDirectory->Get("h_up_win");//get histogram from TTree to h1
  
//[He3 gas in TC]
  TFile *f_he3=new TFile(rootfile_path_he3);
  TTree *tr_he3=(TTree*)f_he3->Get("T");//specify TTree
  c_down->cd(3);
  tr_he3->Draw(p_yfp_sim+":"+p_xfp_sim+">>h_he3"+hist2D,"","colz");;
  TH2F *h_he3 = (TH2F*)gDirectory->Get("h_he3");//get histogram from TTree to h1
  
//[N2 gas flow inside the chamber (upstream)]
  TFile *f_n2=new TFile(rootfile_path_n2);
  TTree *tr_n2=(TTree*)f_n2->Get("T");//specify TTree
  c_down->cd(4);
  tr_n2->Draw(p_yfp_sim+":"+p_xfp_sim+">>h_n2"+hist2D,"","colz");;
  TH2F *h_n2 = (TH2F*)gDirectory->Get("h_n2");//get histogram from TTree to h1  
  
  
//[replay of DIS production cell runs]
  TFile *f_re=new TFile(rootfile_path_replay);
  TTree *tr_re=(TTree*)f_re->Get("T");//specify TTree
  c_down->cd(5);
  tr_re->Draw(p_yfp_re+":"+p_xfp_re+">>h_replay"+hist2D,"","colz");;
  TH2F *h_replay = (TH2F*)gDirectory->Get("h_replay");//get histogram from TTree to h1
 
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Plot 1D y_beam and x_beam
  TCanvas *c_1d=new TCanvas("c_1d","",1200,1200);
  c_1d->Divide(2,2);  
  TFile *f_he3_1d=new TFile(rootfile_path_he3);
  TTree *tr_he3_1d=(TTree*)f_he3_1d->Get("T");//specify TTree
  c_1d->cd(1); 
  tr_he3_1d->Draw(p_xfp_sim+">>h_sim_xbeam"+hist1D);;
  TH1F *h_sim_xbeam = (TH1F*)gDirectory->Get("h_sim_xbeam");//get histogram from TTree to h1
  c_1d->cd(2); 
  tr_he3_1d->Draw(p_yfp_sim+">>h_he3_ybeam"+hist1D);;
  TH1F *h_sim_ybeam = (TH1F*)gDirectory->Get("h_sim_ybeam");//get histogram from TTree to h1 
  
  TFile *f_re_1d=new TFile(rootfile_path_replay);
  TTree *tr_re_1d=(TTree*)f_re_1d->Get("T");//specify TTree
  c_1d->cd(3); 
  tr_re_1d->Draw(p_xfp_re+">>h_replay_xbeam"+hist1D);;
  TH1F *h_replay_xbeam = (TH1F*)gDirectory->Get("h_replay_xbeam");//get histogram from TTree to h1
  c_1d->cd(4); 
  tr_re_1d->Draw(p_yfp_re+">>h_replay_ybeam"+hist1D);;
  TH1F *h_replay_ybeam = (TH1F*)gDirectory->Get("h_replay_ybeam");//get histogram from TTree to h1
    
}

int main()
{ 
  
  XStree_shms_combined_target_sim_xbeam_vs_ybeam();
  return 0;
 
}
