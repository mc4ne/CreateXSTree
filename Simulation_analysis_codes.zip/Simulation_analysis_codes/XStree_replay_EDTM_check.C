//This code is to check EDTM events are not counted for replayed runs
//"T.shms.pEDTM_tdcTimeRaw" should be zero

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include "TH2F.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TStyle.h"
#include "TVirtualPad.h"
#include <string>
#include <sstream>
#include <cmath>

using namespace std;
void XStree_replay_EDTM_check()
{
  //Load root file
  
  //kin-3

  TString rootfile_kine3_replay="hms_replay_production_all_03147_200500.root";
  TString rootfile_kine3_empty="hms_replay_production_all_03072_200500.root";//empty target
  
  
  //kin-4

  TString rootfile_kine4_replay="hms_replay_production_all_03408_200500.root";
  TString rootfile_kine4_empty="hms_replay_production_all_03077_200500.root";//empty target
  
  //[SHMS]

  //kin-B

  TString rootfile_kineB_replay="shms_replay_production_all_10602_200500.root";
  TString rootfile_kineB_empty="shms_replay_production_all_10267_200500.root";//empty target

  

  //kin-C

  TString rootfile_kineC_replay="shms_replay_production_all_10435_200500.root";
  TString rootfile_kineC_empty="shms_replay_production_all_10262_200500.root";//empty target


 
 //[HMS]
 TString h_EDTM="T.hms.hEDTM_tdcTimeRaw";
 TString hist_EDTM="(200, -1, 1)";

 
 

 //[SHMS]
 TString p_EDTM="T.shms.pEDTM_tdcTimeRaw";
 //TString hist_EDTM="(200, -1.0, 1.0)";

 
  
  
  

//[HMS runs]
  TCanvas *c_hms=new TCanvas("c_hms","",1200,1200);
  c_hms->Divide(2,2);  
 //[kine3]
  TFile *f_kine3_re=new TFile(rootfile_kine3_replay);
  TTree *tr_kine3_re=(TTree*)f_kine3_re->Get("T");//specify TTree
  c_hms->cd(1);
  tr_kine3_re->Draw(h_EDTM+">>h_kine3_prod"+hist_EDTM);;
  TH1F *h_kine3_prod = (TH1F*)gDirectory->Get("h_kine3_prod");//get histogram from TTree to h1
  //Empty target
  TFile *f_kine3_em=new TFile(rootfile_kine3_empty);
  TTree *tr_kine3_em=(TTree*)f_kine3_em->Get("T");//specify TTree
  c_hms->cd(2);
  tr_kine3_em->Draw(h_EDTM+">>h_kine3_empty"+hist_EDTM);;
  TH1F *h_kine3_empty = (TH1F*)gDirectory->Get("h_kine3_empty");//get histogram from TTree to h1
 
 //[kine4]
  TFile *f_kine4_re=new TFile(rootfile_kine4_replay);
  TTree *tr_kine4_re=(TTree*)f_kine4_re->Get("T");//specify TTree
  c_hms->cd(3);
  tr_kine4_re->Draw(h_EDTM+">>h_kine4_prod"+hist_EDTM);;
  TH1F *h_kine4_prod = (TH1F*)gDirectory->Get("h_kine4_prod");//get histogram from TTree to h1
  //Empty target
  TFile *f_kine4_em=new TFile(rootfile_kine4_empty);
  TTree *tr_kine4_em=(TTree*)f_kine4_em->Get("T");//specify TTree
  c_hms->cd(4);
  tr_kine4_em->Draw(h_EDTM+">>h_kine4_empty"+hist_EDTM);;
  TH1F *h_kine4_empty = (TH1F*)gDirectory->Get("h_kine4_empty");//get histogram from TTree to h1
 
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//[SHMS runs]
  TCanvas *c_shms=new TCanvas("c_shms","",1200,1200);
  c_shms->Divide(2,2);  
 //[kineB]
  TFile *f_kineB_re=new TFile(rootfile_kineB_replay);
  TTree *tr_kineB_re=(TTree*)f_kineB_re->Get("T");//specify TTree
  c_shms->cd(1);
  tr_kineB_re->Draw(p_EDTM+">>h_kineB_prod"+hist_EDTM);;
  TH1F *h_kineB_prod = (TH1F*)gDirectory->Get("h_kineB_prod");//get histogram from TTree to h1
  //Empty target
  TFile *f_kineB_em=new TFile(rootfile_kineB_empty);
  TTree *tr_kineB_em=(TTree*)f_kineB_em->Get("T");//specify TTree
  c_shms->cd(2);
  tr_kineB_em->Draw(p_EDTM+">>h_kineB_empty"+hist_EDTM);;
  TH1F *h_kineB_empty = (TH1F*)gDirectory->Get("h_kineB_empty");//get histogram from TTree to h1
 
 //[kineC]
  TFile *f_kineC_re=new TFile(rootfile_kineC_replay);
  TTree *tr_kineC_re=(TTree*)f_kineC_re->Get("T");//specify TTree
  c_shms->cd(3);
  tr_kineC_re->Draw(p_EDTM+">>h_kineC_prod"+hist_EDTM);;
  TH1F *h_kineC_prod = (TH1F*)gDirectory->Get("h_kineC_prod");//get histogram from TTree to h1
  //Empty target
  TFile *f_kineC_em=new TFile(rootfile_kineC_empty);
  TTree *tr_kineC_em=(TTree*)f_kineC_em->Get("T");//specify TTree
  c_shms->cd(4);
  tr_kineC_em->Draw(p_EDTM+">>h_kineC_empty"+hist_EDTM);;
  TH1F *h_kineC_empty = (TH1F*)gDirectory->Get("h_kineC_empty");//get histogram from TTree to h1
  
  
}

int main()
{ 
  
  XStree_replay_EDTM_check();
  return 0;
 
}
