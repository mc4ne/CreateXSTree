//This code is to find variables that calculate the yield for replayed runs
//Count="Accepted Physics Triggers (#)"
//Charge="BCM1: (uC)" (Gated Charge)

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include "TH2F.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TStyle.h"
#include "TVirtualPad.h"
#include <string>
#include <sstream>
#include <cmath>

using namespace std;
void report_get_yield()
{
//Load report file
  
  //kin-3
  TString reportfile_path="hms_replay_production_all_03147_200500.report";
  string count_var_name="Accepted Physics Triggers      :"; 
  string count_re;
  float_t count_num;
  
  string charge_var_name="BCM1:";
  string charge_re;
  float_t charge_num;
  
//Find count 
  ifstream report_file(reportfile_path);
  
  string line1;
    while (getline(report_file, line1)) {
        if (line1.find(count_var_name) != string::npos) {
            cout << line1 << endl;
            count_re=line1;}
        else if (line1.find(charge_var_name) != string::npos) {
            cout << line1 << endl;
            charge_re=line1;}   
        
      
    }
   cout<<"Count= "<<count_re<<endl; 
   cout<<"Charge= "<<charge_re<<endl;
//get double from a string
   stringstream ss;     
  
    //Storing the whole string into string stream
    ss << count_re; 
  
    //Running loop till the end of the stream 
    string temp; 
    
    while (!ss.eof()) { 
  
        //extracting word by word from stream 
        ss >> temp; 
  
        //Checking the given word is integer or not 
        if (stringstream(temp) >> count_num) 
             
  
        //To save from space at the end of string 
        temp = ""; 
   }
 
    cout<<"Count num= "<<count_num<<endl; 
  

//get double from a string
   stringstream ss2;     
  
    //Storing the whole string into string stream 
    ss2 << charge_re; 
  
    //Running loop till the end of the stream 
    string temp2; 
    double found; // try to find the middle double num
    int i=1;//index of found double num
    while (!ss2.eof()) { 
  
        //extracting word by word from stream 
        ss2 >> temp2; 
  
        //Checking the given word is integer or not 
        if (stringstream(temp2) >> found) 
            { 
              if (i==1)
                {charge_num=found;}
                i++;
             //To save from space at the end of string 
             temp2 = ""; }
   }
   
    cout<<"Charge num= "<<charge_num<<endl; //charge in [uC]
//calculate yield  
float_t inv_charge=(1/(charge_num*1e-6));
cout<<"inverse_charge (C-1)"<<inv_charge<<endl;  
float_t yield = (count_num/(charge_num*1e-6));//convert double to string
cout<<"Yield= "<<yield<<endl; 
TString yield_mult;
yield_mult.Form("%f",yield);//%f for flate number; \n for start a newline 
cout<<"Yield mult= "<<yield_mult<<endl; 


TString test, yield_re;
test="*";
yield_re=yield_mult+test;
cout<<"Yield replay= "<<yield_re<<endl;
}

int main()
{ 
  
  report_get_yield();
  return 0;
 
}
