//This code is to plot z_ini and z_recon with weighted rate and Q2<11 GeV^2 cut from mc_single_arm simulation for GE180 glass windows
//note that PBosted::GetXS() will not work for Q2>11, I give up these points
//For HMS: ztg0; ztg; Q2; p_rate_ge180; p_rate_he3 (T)
//For SHMS:ztg0; ztg; Q2; p_rate_ge180; p_rate_he3(T)
//For replayed root file tree branches: z_recon=H.react.z; beam_current=ibcm1
// gPad->SetLogy();//set log scale for y-axis
//Charge="BCM1: (uC)" (Gated Charge)
//Yield=# of events/Charge
//Use Scale_const for comparison with empty target
 
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include "TH2F.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TStyle.h"
#include "TVirtualPad.h"
#include <string>
#include <sstream>
#include <cmath>

using namespace std;
void XStree_hms_replay_sim_comparsion_yield_charge()
{
  //Load root file
  /*
  //kin-3
  TString rootfile_path_down="test3_win_down_xstree.root";
  TString rootfile_path_up="test3_win_up_xstree.root";
  TString rootfile_path_he3="test3_xstree.root";
  TString rootfile_path_replay="hms_replay_production_all_03147_200500.root";
  TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03147_200500.report";//replay report file
  //TString rootfile_path_replay="hms_replay_production_all_03072_200500.root";//empty target
  //TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03072_200500.report";//replay report file
  */
  
  //kin-4
  TString rootfile_path_down="test4_win_down_xstree.root";
  TString rootfile_path_up="test4_win_up_xstree.root";
  TString rootfile_path_he3="test4_xstree.root";
  TString rootfile_path_replay="hms_replay_production_all_03408_200500.root";
  TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03408_200500.report";//replay report file
  //TString rootfile_path_replay="hms_replay_production_all_03077_200500.root";//empty target
  //TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03077_200500.report";//replay report file
  
  //[SHMS]
  /*
  //kin-B
  TString rootfile_path_down="shms_b_win_downstream_xstree.root";
  TString rootfile_path_up="shms_b_win_upstream_xstree.root";
  TString rootfile_path_he3="shms_b_xstree.root";
  //TString rootfile_path_replay="shms_replay_production_all_10602_200500.root";
  TString rootfile_path_replay="shms_replay_production_all_10267_200500.root";//empty target
  */
  
  /*
  //kin-C
  TString rootfile_path_down="shms_c_win_downstream_xstree.root";
  TString rootfile_path_up="shms_c_win_upstream_xstree.root";
  TString rootfile_path_he3="shms_c_xstree.root";
  //TString rootfile_path_replay="shms_replay_production_all_10435_200500.root";
  TString rootfile_path_replay="shms_replay_production_all_10262_200500.root";//empty target
  */ 
   
 //TTree strings
 TString p_zini="ztg0";
 TString p_zrecon="ztg";
 TString hist_z="(400, -40.0, 40.0)";
 
 TString p_dpini="delta0";
 TString p_dprecon="delta";
 TString hist_dp="(400, -30.0, 30.0)";

 
 TString p_thini="xptg0";
 TString p_threcon="xptg";
 TString hist_th="(400, -.3, .3)";
 
 TString p_phini="yptg0";
 TString p_phrecon="yptg";
 TString hist_ph="(400, -.3, .3)";
 
 cout<<"plot="<<p_zrecon<<endl;

//HMS sim cut
 TString cut_dp_sim="delta>-8&&delta<8";//cut on dp for simulated run
 TString cut_th_sim="xptg>-0.07&&xptg<0.07";
 TString cut_ph_sim="yptg>-0.1&&yptg<0.1";

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Determined yield for replayed runs from the ".report" file  (yield=count/charge)
 
  
  string charge_var_name="BCM1:";
  string charge_re;
  double charge_num;
  
//Find count 
  ifstream report_file(reportfile_path);
  
  string line1;
    while (getline(report_file, line1)) {
        if (line1.find(charge_var_name) != string::npos) {
            cout << line1 << endl;
            charge_re=line1;} 
        
      
    }
  

//get double from a string
   stringstream ss2;     
  
    //Storing the whole string into string stream 
    ss2 << charge_re; 
  
    //Running loop till the end of the stream 
    string temp2; 
    double found; // try to find the middle double num
    int i=1;//index of found double num
    while (!ss2.eof()) { 
  
        //extracting word by word from stream 
        ss2 >> temp2; 
  
        //Checking the given word is integer or not 
        if (stringstream(temp2) >> found) 
            { 
              if (i==1)
                {charge_num=found;}
                i++;
             //To save from space at the end of string 
             temp2 = ""; }
   }
   
    cout<<"Charge num= "<<charge_num<<endl; //charge in [uC]  
//calculate yield    
float_t yield = (1/(charge_num*1e-6));//calculate factor for yield
cout<<"Yield= "<<yield<<endl; 
TString yield_re;
yield_re.Form("%f",yield);//convert double to string %f for flate number; \n for start a newline 
cout<<"Yield mult= "<<yield_re<<endl;


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 
 //[HMS]
 TString p_zrecon_re="H.react.z";
 TString p_dprecon_re="H.gtr.dp";
 TString p_threcon_re="H.gtr.th";
 TString p_phrecon_re="H.gtr.ph";
 //cut on replayed run
 TString p_dprecon_cut="H.gtr.dp>-8&&H.gtr.dp<8";//dp cut for HMS: (-8%,8%)
 TString p_threcon_cut="H.gtr.th>-0.07&&H.gtr.th<0.07";//th_accept = (70.0+abs(-70.0))/1000.0;
 TString p_phrecon_cut="H.gtr.ph>-0.1&&H.gtr.ph<0.1";//ph_accept = (100.0+abs(-100.0))/1000.0;
 TString p_ibcm1_cut="&& ibcm1>1.0";//current>1.0 uA
 //TString p_ibcm1_cut="";
 //HMS PID cut
 TString p_pid_cut="&& H.cal.etracknorm>0.8 && H.cal.etracknorm<2. && H.cer.npeSum>1";//last cut
 //TString p_pid_cut="";//without cut
 
 /*
 //[SHMS]
 TString p_zrecon_re="P.react.z";
 TString p_dprecon_re="P.gtr.dp";
 TString p_threcon_re="P.gtr.th";
 TString p_phrecon_re="P.gtr.ph";
 //cut on replayed run
 TString p_dprecon_cut="P.gtr.dp>-10&&P.gtr.dp<22";//dp for SHMS: (-10%,22%)
 TString p_threcon_cut="P.gtr.th>-0.055&&P.gtr.th<0.055";// th_accept = (55.0+abs(-55.0))/1000.0;
 TString p_phrecon_cut="P.gtr.ph>-0.05&&P.gtr.ph<0.05";// ph_accept = (50.0+abs(-50.0))/1000.0;
 */
 
 
 
 //Created combined histogram
 //Combined simulation
 TH1F *h_sim_comb_z=new TH1F("h_sim_comb_z","ztg simulation combined Weighted by Yield",400, -40.0, 40.0);
 TH1F *h_sim_comb_dp=new TH1F("h_sim_comb_dp","delta simulation combined Weighted by Yield",400, -30.0, 30.0);
 TH1F *h_sim_comb_th=new TH1F("h_sim_comb_th","theta simulation combined Weighted by Yield",400, -.3, .3);
 TH1F *h_sim_comb_ph=new TH1F("h_sim_comb_ph","phi simulation combined Weighted by Yield",400, -.3, .3);
 //[Stacked Histogram]
 THStack *hs_comb_z= new THStack("hs_comb_z","ztg_combined Weighted by Yield");
 THStack *hs_comb_dp= new THStack("hs_comb_dp","delta_combined Weighted by Yield");
 THStack *hs_comb_th= new THStack("hs_comb_th","theta_combined Weighted by Yield");
 THStack *hs_comb_ph= new THStack("hs_comb_ph","phi_combined Weighted by Yield");
 

 //[downstream window]
 TFile *f_down=new TFile(rootfile_path_down);
  TTree *tr_down=(TTree*)f_down->Get("T");//specify TTree
  TCanvas *c_down=new TCanvas("c_down","",1800,1200);
  c_down->Divide(2,2);
  //ztar
  c_down->cd(1);
  tr_down->Draw(p_zrecon+">>h_down_z"+hist_z,"p_yield_ge180*("+p_zrecon+">5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");//add"HIST" for not showing the error bars
  TH1F *h_down_z = (TH1F*)gDirectory->Get("h_down_z");//get histogram from TTree to h1
  h_down_z->SetLineColor(kRed);
  double scale_down;
  scale_down=h_down_z->GetBinContent(300);//get specific bin height
  cout<<"bin height at 20="<<scale_down<<endl;
  hs_comb_z->Add(h_down_z);
  //dptar
  c_down->cd(2);
  tr_down->Draw(p_dprecon+">>h_down_dp"+hist_dp,"p_yield_ge180*("+p_zrecon+">5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");//add"HIST" for not showing the error bars
  TH1F *h_down_dp = (TH1F*)gDirectory->Get("h_down_dp");//get histogram from TTree to h1
  h_down_dp->SetLineColor(kRed);
  hs_comb_dp->Add(h_down_dp);
  //thtar
  c_down->cd(3);
  tr_down->Draw(p_threcon+">>h_down_th"+hist_th,"p_yield_ge180*("+p_zrecon+">5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");//add"HIST" for not showing the error bars
  TH1F *h_down_th = (TH1F*)gDirectory->Get("h_down_th");//get histogram from TTree to h1
  h_down_th->SetLineColor(kRed);
  hs_comb_th->Add(h_down_th);
  //phtar
  c_down->cd(4);
  tr_down->Draw(p_phrecon+">>h_down_ph"+hist_ph,"p_yield_ge180*("+p_zrecon+">5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");//add"HIST" for not showing the error bars
  TH1F *h_down_ph = (TH1F*)gDirectory->Get("h_down_ph");//get histogram from TTree to h1
  h_down_ph->SetLineColor(kRed);
  hs_comb_ph->Add(h_down_ph);
  
  
//[upstream window]
  TFile *f_up=new TFile(rootfile_path_up);
  TTree *tr_up=(TTree*)f_up->Get("T");//specify TTree
  TCanvas *c_up =new TCanvas("c_up","",1800,1200);
  c_up->Divide(2,2);
  //ztar
  c_up->cd(1);
  tr_up->Draw(p_zrecon+">>h_up_z"+hist_z,"p_yield_ge180*("+p_zrecon+"<-5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");
  TH1F *h_up_z = (TH1F*)gDirectory->Get("h_up_z");//get histogram from TTree to h1
  h_up_z->SetLineColor(kBlue);
  hs_comb_z->Add(h_up_z);
  //dptar
  c_up->cd(2);
  tr_up->Draw(p_dprecon+">>h_up_dp"+hist_dp,"p_yield_ge180*("+p_zrecon+"<-5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");
  TH1F *h_up_dp = (TH1F*)gDirectory->Get("h_up_dp");//get histogram from TTree to h1
  h_up_dp->SetLineColor(kBlue);
  hs_comb_dp->Add(h_up_dp);
  //thtar
  c_up->cd(3);
  tr_up->Draw(p_threcon+">>h_up_th"+hist_th,"p_yield_ge180*("+p_zrecon+"<-5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");//add"HIST" for not showing the error bars
  TH1F *h_up_th = (TH1F*)gDirectory->Get("h_up_th");//get histogram from TTree to h1
  h_up_th->SetLineColor(kBlue);
  hs_comb_th->Add(h_up_th);
  //phtar
  c_up->cd(4);
  tr_up->Draw(p_phrecon+">>h_up_ph"+hist_ph,"p_yield_ge180*("+p_zrecon+"<-5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST");//add"HIST" for not showing the error bars
  TH1F *h_up_ph = (TH1F*)gDirectory->Get("h_up_ph");//get histogram from TTree to h1
  h_up_ph->SetLineColor(kBlue);
  hs_comb_ph->Add(h_up_ph);
  
  
//[He3 gas in TC]
  TFile *f_he3=new TFile(rootfile_path_he3);
  TTree *tr_he3=(TTree*)f_he3->Get("T");//specify TTree
  TCanvas *c_he3 =new TCanvas("c_he3","",1800,1200);
  c_he3->Divide(2,2);
  //ztar
  c_he3->cd(1);
  tr_he3->Draw(p_zrecon+">>h_he3_z"+hist_z,"p_yield_he3*("+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST"); 
  TH1F *h_he3_z = (TH1F*)gDirectory->Get("h_he3_z");//get histogram from TTree to h1
  h_he3_z->SetLineColor(kGreen);
  double scale_middle;
  scale_middle=h_he3_z->GetBinContent(200);//get specific bin height
  cout<<"bin height at 0.0="<<scale_middle<<endl;
  hs_comb_z->Add(h_he3_z);
  //dptar
  c_he3->cd(2);
  tr_he3->Draw(p_dprecon+">>h_he3_dp"+hist_dp,"p_yield_he3*("+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST"); 
  TH1F *h_he3_dp = (TH1F*)gDirectory->Get("h_he3_dp");//get histogram from TTree to h1
  h_he3_dp->SetLineColor(kGreen);
  hs_comb_dp->Add(h_he3_dp);
  //thtar
  c_he3->cd(3);
  tr_he3->Draw(p_threcon+">>h_he3_th"+hist_th,"p_yield_he3*("+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST"); 
  TH1F *h_he3_th = (TH1F*)gDirectory->Get("h_he3_th");//get histogram from TTree to h1
  h_he3_th->SetLineColor(kGreen);
  hs_comb_th->Add(h_he3_th);
  //phtar
  c_he3->cd(4);
  tr_he3->Draw(p_phrecon+">>h_he3_ph"+hist_ph,"p_yield_he3*("+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","HIST"); 
  TH1F *h_he3_ph = (TH1F*)gDirectory->Get("h_he3_ph");//get histogram from TTree to h1
  h_he3_ph->SetLineColor(kGreen);
  hs_comb_ph->Add(h_he3_ph);
  
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
 //[Add all simulation together]
  //ztar
  h_sim_comb_z->Add(h_down_z);
  h_sim_comb_z->Add(h_up_z);
  h_sim_comb_z->Add(h_he3_z);
  h_sim_comb_z->SetLineColor(kMagenta);
  hs_comb_z->Add(h_sim_comb_z);
  //dptar
  h_sim_comb_dp->Add(h_down_dp);
  h_sim_comb_dp->Add(h_up_dp);
  h_sim_comb_dp->Add(h_he3_dp);
  h_sim_comb_dp->SetLineColor(kMagenta);
  hs_comb_dp->Add(h_sim_comb_dp);
  //thtar
  h_sim_comb_th->Add(h_down_th);
  h_sim_comb_th->Add(h_up_th);
  h_sim_comb_th->Add(h_he3_th);
  h_sim_comb_th->SetLineColor(kMagenta);
  hs_comb_th->Add(h_sim_comb_th);
  //phtar
  h_sim_comb_ph->Add(h_down_ph);
  h_sim_comb_ph->Add(h_up_ph);
  h_sim_comb_ph->Add(h_he3_ph);
  h_sim_comb_ph->SetLineColor(kMagenta);
  hs_comb_ph->Add(h_sim_comb_ph);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
//[replay of DIS production cell runs]
  TFile *f_re=new TFile(rootfile_path_replay);
  TTree *tr_re=(TTree*)f_re->Get("T");//specify TTree
  TCanvas *c_re =new TCanvas("c_re","",1800,1200);
  c_re->Divide(2,2);
  //ztar
  c_re->cd(1);
  tr_re->Draw(p_zrecon_re+">>h_re_z"+hist_z,yield_re+"*("+p_dprecon_cut+"&&"+p_threcon_cut+"&&"+p_phrecon_cut+p_ibcm1_cut+p_pid_cut+")");
  TH1F *h_re_z = (TH1F*)gDirectory->Get("h_re_z");//get histogram from TTree to h1
  h_re_z->SetLineColor(kBlack);
  double scale_re,scale_const;
  scale_re=h_re_z->GetBinContent(200);//get specific bin height
  cout<<"bin height for root file at 0.0="<<scale_re<<endl;
  scale_const=scale_middle/scale_re;//set scale constant for compare sim vs replay
  //scale_const=0.166129;//kin3
  //scale_const=0.489118;//kin4
  cout<<"scale_middle/scale_re= "<<scale_const<<endl;
  //h_re_z->Scale(scale_const);
  hs_comb_z->Add(h_re_z);
  //dptar
  c_re->cd(2);
  tr_re->Draw(p_dprecon_re+">>h_re_dp"+hist_dp, yield_re+"*("+p_dprecon_cut+"&&"+p_threcon_cut+"&&"+p_phrecon_cut+p_ibcm1_cut+p_pid_cut+")");
  //tr_re->Draw(p_dprecon_re+">>h_re_dp"+hist_dp);
  TH1F *h_re_dp = (TH1F*)gDirectory->Get("h_re_dp");//get histogram from TTree to h1
  h_re_dp->SetLineColor(kBlack);
  //h_re_dp->Scale(scale_const);
  hs_comb_dp->Add(h_re_dp);
  //thtar
  c_re->cd(3);
  tr_re->Draw(p_threcon_re+">>h_re_th"+hist_th,yield_re+"*("+p_dprecon_cut+"&&"+p_threcon_cut+"&&"+p_phrecon_cut+p_ibcm1_cut+p_pid_cut+")");
  TH1F *h_re_th = (TH1F*)gDirectory->Get("h_re_th");//get histogram from TTree to h1
  h_re_th->SetLineColor(kBlack);
  //h_re_th->Scale(scale_const);
  hs_comb_th->Add(h_re_th);
  //phtar
  c_re->cd(4);
  tr_re->Draw(p_phrecon_re+">>h_re_ph"+hist_th,yield_re+"*("+p_dprecon_cut+"&&"+p_threcon_cut+"&&"+p_phrecon_cut+p_ibcm1_cut+p_pid_cut+")");
  TH1F *h_re_ph = (TH1F*)gDirectory->Get("h_re_ph");//get histogram from TTree to h1
  h_re_ph->SetLineColor(kBlack);
  //h_re_ph->Scale(scale_const);
  hs_comb_ph->Add(h_re_ph);

  
  
 //[Combined Target sim]:stack
 TCanvas *cs_comb =new TCanvas("cs_comb","",1800,1200);
  cs_comb->Divide(2,2);
  //ztar
  cs_comb->cd(1);
  hs_comb_z->Draw("HIST, nostack");//plot nostack histrogams
  //Legend
  TLegend* legend_hs1_z= new TLegend(0.65, 0.52, .82, .85);
  legend_hs1_z->AddEntry(h_down_z, "Down Win", "lp");
  legend_hs1_z->AddEntry(h_up_z, "Up Win", "lp");
  legend_hs1_z->AddEntry(h_he3_z, "He3 Target", "lp");
  legend_hs1_z->AddEntry(h_sim_comb_z, "Simulation Combined", "lp");
  legend_hs1_z->AddEntry(h_re_z, "Replay", "lp");
  legend_hs1_z->Draw();

  //dptar
  cs_comb->cd(2);
  hs_comb_dp->Draw("HIST, nostack");//plot nostack histrogams
  //Legend
  TLegend* legend_hs1_dp= new TLegend(0.65, 0.52, .82, .85);
  legend_hs1_dp->AddEntry(h_down_dp, "Down Win", "lp");
  legend_hs1_dp->AddEntry(h_up_dp, "Up Win", "lp");
  legend_hs1_dp->AddEntry(h_he3_dp, "He3 Target", "lp");
  legend_hs1_dp->AddEntry(h_sim_comb_dp, "Simulation Combined", "lp");
  legend_hs1_dp->AddEntry(h_re_dp, "Replay", "lp");
  legend_hs1_dp->Draw(); 
  
  //thtar
  cs_comb->cd(3);
  hs_comb_th->Draw("HIST, nostack");//plot nostack histrogams
  //Legend
  TLegend* legend_hs1_th= new TLegend(0.65, 0.52, .82, .85);
  legend_hs1_th->AddEntry(h_down_th, "Down Win", "lp");
  legend_hs1_th->AddEntry(h_up_th, "Up Win", "lp");
  legend_hs1_th->AddEntry(h_he3_th, "He3 Target", "lp");
  legend_hs1_th->AddEntry(h_sim_comb_th, "Simulation Combined", "lp");
  legend_hs1_th->AddEntry(h_re_th, "Replay", "lp");
  legend_hs1_th->Draw(); 
  
  //phtar
  cs_comb->cd(4);
  hs_comb_ph->Draw("HIST, nostack");//plot nostack histrogams
  //Legend
  TLegend* legend_hs1_ph= new TLegend(0.65, 0.52, .82, .85);
  legend_hs1_ph->AddEntry(h_down_ph, "Down Win", "lp");
  legend_hs1_ph->AddEntry(h_up_ph, "Up Win", "lp");
  legend_hs1_ph->AddEntry(h_he3_ph, "He3 Target", "lp");
  legend_hs1_ph->AddEntry(h_sim_comb_ph, "Simulation Combined", "lp");
  legend_hs1_ph->AddEntry(h_re_ph, "Replay", "lp");
  legend_hs1_ph->Draw(); 
}

int main()
{ 
  
  XStree_hms_replay_sim_comparsion_yield_charge();
  return 0;
 
}
