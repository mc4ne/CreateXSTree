//This code is to plot z_ini and z_recon with weighted rate and Q2<11 GeV^2 cut from mc_single_arm simulation for GE180 glass windows
//note that PBosted::GetXS() will not work for Q2>11, I give up these points
//For HMS: ztg0; ztg; Q2; p_rate_ge180; p_rate_he3 (T)
//For SHMS:ztg0; ztg; Q2; p_rate_ge180; p_rate_he3(T)
//Plot 2D histogram of xfp vs yfp

#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include "TH2F.h"
#include "TF1.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TStyle.h"
#include "TVirtualPad.h"
#include <string>
#include <sstream>
#include <cmath>

using namespace std;
void XStree_shms_combined_target_sim_xfp_vs_yfp()
{
  //Load root file
  
  /*
  //kin-3
  TString rootfile_path_down="test3_win_down_xstree.root";
  TString rootfile_path_up="test3_win_up_xstree.root";
  TString rootfile_path_he3="test3_xstree.root";
  TString rootfile_path_replay="hms_replay_production_all_03147_200500.root";
  TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03147_200500.report";//replay report file
  //TString rootfile_path_replay="hms_replay_production_all_03072_200500.root";//empty target
  //TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03072_200500.report";//replay report file
  */
  /*
  //kin-4
  TString rootfile_path_down="test4_win_down_xstree.root";
  TString rootfile_path_up="test4_win_up_xstree.root";
  TString rootfile_path_he3="test4_xstree.root";
  TString rootfile_path_replay="hms_replay_production_all_03408_200500.root";
  TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03408_200500.report";//replay report file
  //TString rootfile_path_replay="hms_replay_production_all_03077_200500.root";//empty target
  //TString reportfile_path="./Replay_report_files_2021/hms_replay_production_all_03077_200500.report";//replay report file
  */
  //[SHMS]
  /*
  //kin-B
  TString rootfile_path_down="shms_b_win_downstream_xstree.root";
  TString rootfile_path_up="shms_b_win_upstream_xstree.root";
  TString rootfile_path_he3="shms_b_xstree.root";
  TString rootfile_path_n2="shms_b_n2_xstree.root";
  TString rootfile_path_replay="shms_replay_production_all_10602_200500.root";
  TString reportfile_path="./Replay_report_files_2021/shms_replay_production_all_10602_200500.report";//replay report file
  //TString rootfile_path_replay="shms_replay_production_all_10267_200500.root";//empty target
  //TString reportfile_path="./Replay_report_files_2021/shms_replay_production_all_10267_200500.report";//replay report file
  */
  
  //kin-C
  TString rootfile_path_down="shms_c_win_downstream_xstree.root";
  TString rootfile_path_up="shms_c_win_upstream_xstree.root";
  TString rootfile_path_he3="shms_c_xstree.root";
  TString rootfile_path_n2="shms_c_n2_xstree.root"; 
  TString rootfile_path_replay="shms_replay_production_all_10435_200500.root";
  TString reportfile_path="./Replay_report_files_2021/shms_replay_production_all_10435_200500.report";//replay report file
  //TString rootfile_path_replay="shms_replay_production_all_10262_200500.root";//empty target
  //TString reportfile_path="./Replay_report_files_2021/shms_replay_production_all_10262_200500.report";//replay report file
   
   
 //TTree strings
 TString p_xfp_sim="xfp";
 TString p_yfp_sim="yfp";
 TString p_zrecon="ztg";
 TString hist2D="(200, -60, 60, 200, -60, 60)";//x and y bin range
/*
 //[HMS]
 TString p_xfp_re="H.dc.x_fp";
 TString p_yfp_re="H.dc.y_fp";
*/
 
 
 //[SHMS]
 TString p_xfp_re="P.dc.x_fp";
 TString p_yfp_re="P.dc.y_fp";

 /*
//HMS sim cut
 TString cut_dp_sim="delta>-8&&delta<8";//cut on dp for simulated run
 TString cut_th_sim="xptg>-0.07&&xptg<0.07";
 TString cut_ph_sim="yptg>-0.1&&yptg<0.1";
*/
//SHMS sim cut
 TString cut_dp_sim="delta>-10&&delta<22";//cut on dp for simulated run
 TString cut_th_sim="xptg>-0.055&&xptg<0.055";
 TString cut_ph_sim="yptg>-0.05&&yptg<0.05"; 
 

 //cut on replayed run
 TString p_dprecon_cut="P.gtr.dp>-10&&P.gtr.dp<22";//dp for SHMS: (-10%,22%)
 TString p_threcon_cut="P.gtr.th>-0.055&&P.gtr.th<0.055";// th_accept = (55.0+abs(-55.0))/1000.0;
 TString p_phrecon_cut="P.gtr.ph>-0.05&&P.gtr.ph<0.05";// ph_accept = (50.0+abs(-50.0))/1000.0;
 
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Determined yield for replayed runs from the ".report" file  (yield=count/charge)
 
  
  string charge_var_name="BCM1:";
  string charge_re;
  double charge_num;
  
//Find count 
  ifstream report_file(reportfile_path);
  
  string line1;
    while (getline(report_file, line1)) {
        if (line1.find(charge_var_name) != string::npos) {
            cout << line1 << endl;
            charge_re=line1;} 
        
      
    }
  

//get double from a string
   stringstream ss2;     
  
    //Storing the whole string into string stream 
    ss2 << charge_re; 
  
    //Running loop till the end of the stream 
    string temp2; 
    double found; // try to find the middle double num
    int i=1;//index of found double num
    while (!ss2.eof()) { 
  
        //extracting word by word from stream 
        ss2 >> temp2; 
  
        //Checking the given word is integer or not 
        if (stringstream(temp2) >> found) 
            { 
              if (i==1)
                {charge_num=found;}
                i++;
             //To save from space at the end of string 
             temp2 = ""; }
   }
   
    cout<<"Charge num= "<<charge_num<<endl; //charge in [uC]  
//calculate yield    
float_t yield = (1/(charge_num*1e-6));//calculate factor for yield
cout<<"Yield= "<<yield<<endl; 
TString yield_re;
yield_re.Form("%f",yield);//convert double to string %f for flate number; \n for start a newline 
cout<<"Yield mult= "<<yield_re<<endl;
  
  
 
 
 
 
 //[downstream window]
 TFile *f_down=new TFile(rootfile_path_down);
  TTree *tr_down=(TTree*)f_down->Get("T");//specify TTree
  TCanvas *c_down=new TCanvas("c_down","",1800,1200);
  c_down->Divide(3,2);
  c_down->cd(1);
  tr_down->Draw(p_xfp_sim+":"+p_yfp_sim+">>h_down_win"+hist2D,"p_yield_ge180*("+p_zrecon+">5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","colz");;
  TH2F *h_down_win = (TH2F*)gDirectory->Get("h_down_win");//get histogram from TTree to h1
  
  
  
//[upstream window]
  TFile *f_up=new TFile(rootfile_path_up);
  TTree *tr_up=(TTree*)f_up->Get("T");//specify TTree
  c_down->cd(2);
  tr_up->Draw(p_xfp_sim+":"+p_yfp_sim+">>h_up_win"+hist2D,"p_yield_ge180*("+p_zrecon+"<-5.0&&"+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","colz");;
  TH2F *h_up_win = (TH2F*)gDirectory->Get("h_up_win");//get histogram from TTree to h1
  
//[He3 gas in TC]
  TFile *f_he3=new TFile(rootfile_path_he3);
  TTree *tr_he3=(TTree*)f_he3->Get("T");//specify TTree
  c_down->cd(3);
  tr_he3->Draw(p_xfp_sim+":"+p_yfp_sim+">>h_he3"+hist2D,"p_yield_he3*("+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","colz");;
  TH2F *h_he3 = (TH2F*)gDirectory->Get("h_he3");//get histogram from TTree to h1
  
//[N2 gas flow inside the chamber (upstream)]  
  TFile *f_n2=new TFile(rootfile_path_n2);
  TTree *tr_n2=(TTree*)f_n2->Get("T");//specify TTree
  c_down->cd(4);
  tr_n2->Draw(p_xfp_sim+":"+p_yfp_sim+">>h_n2"+hist2D,"p_yield_n2*1e-6*("+cut_dp_sim+"&&"+cut_th_sim+"&&"+cut_ph_sim+")","colz");;
  TH2F *h_n2 = (TH2F*)gDirectory->Get("h_n2");//get histogram from TTree to h1

//[replay of DIS production cell runs]
  TFile *f_re=new TFile(rootfile_path_replay);
  TTree *tr_re=(TTree*)f_re->Get("T");//specify TTree
  c_down->cd(5);
  tr_re->Draw(p_xfp_re+":"+p_yfp_re+">>h_replay"+hist2D,yield_re+"*("+p_dprecon_cut+"&&"+p_threcon_cut+"&&"+p_phrecon_cut+")","colz");;
  TH2F *h_replay = (TH2F*)gDirectory->Get("h_replay");//get histogram from TTree to h1
 

    
}

int main()
{ 
  
  XStree_shms_combined_target_sim_xfp_vs_yfp();
  return 0;
 
}
